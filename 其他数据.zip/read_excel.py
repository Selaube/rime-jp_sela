# encoding: utf-8
import pandas as pd
import xlrd

def read_excel():
    fp = input('输入excel文件的地址：')

    file = xlrd.open_workbook(fp)
    page_num = file.nsheets
    page_name = file.sheet_names()

    sheet_list = []
    for i in range(page_num):
        sheet_list.append(pd.read_excel(fp, page_name[i]))
        print('\r', i, '/', page_num, end='')
    
    print('\nreading finished')
    return sheet_list